package com.keerthi.searchengine.util;

 
public class TimeUtil {

    public static long getCurrentTimeInMs() {
        return System.currentTimeMillis();
    }
}
