package com.keerthi.searchengine.config;


public class XMLPageConfig {
    public static final String ELEMENT_TITLE = "title";
    public static final String ELEMENT_ID = "id";
    public static final String ELEMENT_TEXT = "text";
}
